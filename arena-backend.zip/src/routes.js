function setupRoutes(app) {
    app.get('/health', (req, res) => {
        res.send({ status: 'OK' });
    });
}

module.exports = { setupRoutes };
